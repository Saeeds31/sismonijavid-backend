<?php

return [
    'name' => 'Cart',
];
