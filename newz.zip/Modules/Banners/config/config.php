<?php

return [
    'name' => 'Banners',
];
