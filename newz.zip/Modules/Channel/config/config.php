<?php

return [
    'name' => 'Channel',
];
