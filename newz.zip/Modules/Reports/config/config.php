<?php

return [
    'name' => 'Reports',
];
