<?php

return [
    'name' => 'Shipping',
];
