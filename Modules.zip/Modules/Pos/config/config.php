<?php

return [
    'name' => 'Pos',
];
