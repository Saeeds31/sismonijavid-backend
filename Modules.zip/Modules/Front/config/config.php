<?php

return [
    'name' => 'Front',
];
