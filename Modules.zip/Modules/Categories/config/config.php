<?php

return [
    'name' => 'Categories',
];
